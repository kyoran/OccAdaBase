from .vovnet import VoVNet
from .efficientnet import CustomEfficientNet

__all__ = ['VoVNet', 'CustomEfficientNet']